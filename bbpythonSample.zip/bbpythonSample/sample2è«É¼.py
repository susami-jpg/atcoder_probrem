# -*- coding: utf-8 -*-
"""
Created on Sat Jun 30 17:16:06 2018

@author: tatehide
"""

import requests
import bs4
import csv

try:
    rs = requests.get('http://tatehide.com/bbdata.php')
    rs.raise_for_status()
    sp = bs4.BeautifulSoup(rs.text.encode(rs.encoding), 'html.parser')
    rcd = []
    rcd.append(sp.select_one('#date').string)
                             
    for elm in sp.select('.val'):
        rcd.append(elm.string)
    
    with open('mydata.csv', 'a', newline='') as f:
        wrtr = csv.writer(f, delimiter=',') 
        wrtr.writerow(rcd)
    
except requests.exceptions.RequestException as e:
    print('通信でエラー発生:{}'.format(e.args))
except OSError as e:
    print('ファイル処理でエラー発生:{}'.format(e.args))