# -*- coding: utf-8 -*-
"""
Created on Tue Jul 17 09:11:52 2018

@author: tatehide
"""

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('mydata.csv')
print(df.describe())
print(df.corr()) 
plt.scatter(df['気温'], df['物質A'])
plt.show()