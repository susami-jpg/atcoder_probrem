# -*- coding: utf-8 -*-
"""
Created on Wed May 23 10:32:30 2018

@author: tatehide
"""

import os
import shutil
import datetime
import PIL

MY_DIR = 'photo/'
fldnum = 0
files = os.listdir(MY_DIR)

for i in files:
    img = PIL.Image.open(MY_DIR + i)
    exif = img._getexif()
    img.close()
    dto = exif[36867]
    dt = datetime.datetime.strptime(dto,'%Y:%m:%d %H:%M:%S')
    dpath = MY_DIR + dt.strftime('%Y%m%d')
    
    if os.path.isdir(dpath) == False:
        os.mkdir(dpath)
        fldnum += 1
        
    shutil.move(MY_DIR + i, dpath)
    
print(str(fldnum) + '個のフォルダーを作成しました。')