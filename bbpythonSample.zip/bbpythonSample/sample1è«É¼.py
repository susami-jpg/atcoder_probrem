# -*- coding: utf-8 -*-
"""
Created on Fri Apr 13 08:44:20 2018

@author: tatehide
"""

import os
import shutil
import datetime

MY_DIR = 'photo/'
fldnum = 0
files = os.listdir(MY_DIR)

for i in files:
    mtime = os.path.getmtime(MY_DIR + i)
    dt = datetime.datetime.fromtimestamp(mtime)
    dpath = MY_DIR + dt.strftime('%Y%m%d')
    
    if os.path.isdir(dpath) == False:
        os.mkdir(dpath)
        fldnum += 1
        
    shutil.move(MY_DIR + i, dpath)
    
print(str(fldnum) + '個のフォルダーを作成しました。')